# tectonic_bridge_png 0.1.2 (2026-04-11)

- Add license

# tectonic_bridge_png 0.1.1 (2026-04-11)

- Update bridge_png for publish

# tectonic_bridge_png 0.1.0 (2026-04-11)

A new bridge for use in the `tectonic_xetex_layout` rewrite to Rust. Exposes fontconfig APIs.

