# tectonic_bridge_graphite2 0.3.2 (2026-04-11)

# tectonic_bridge_graphite2 0.3.1 (2026-04-11)

- Fix for publish not going through


# tectonic_bridge_graphite2 0.3.0 (2026-04-11)

- Global lint fixes
- Update to edition 2021
- Expose the C API in Rust for use in `tectonic_xetex_layout` Rust rewrite


# tectonic_bridge_graphite2 0.2.2 (2023-05-18)

- Tidy up recent Clippy warnings.


# tectonic_bridge_graphite2 0.2.1 (2021-10-11)

- Fix the build script for Rust >=1.55 (#820, @pkgw)


# tectonic_bridge_graphite2 0.2.0 (2021-06-03)

- Fix up handling of how C/C++ header file paths are exported to dependent
  crates. This is a breaking change: we've moved from a single include directory
  to a list of them.
- Some improvements to the documentation


# tectonic_bridge_graphite2 0.1.1 (2021-01-16)

- Export information about the `GRAPHITE2_STATIC` C preprocessor define that is
  sometimes needed.


# tectonic_bridge_graphite2 0.1.0 (2021-01-04)

A new crate to encapsulate the location and use of the `graphite2` library used
by Tectonic.
